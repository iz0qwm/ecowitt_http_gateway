<?php
	include("../../../config.php");
	include("../../../css/design.php");
	include("../../../scripts/functions.php");

	$type = $_GET['type'];
	$path = $_GET['path'];
	$maxInterval = $_GET['interval'];
	$path = urldecode($path);

	include("settings.php");
	
		// load API file
	if(file_exists("../../../meteotemplateLive.txt")){
		$apiData = json_decode(file_get_contents("../../../meteotemplateLive.txt"), true);

		$lightning_num = $apiData["L"];		//Number of lightning from the power on
		$lightning_dist = $apiData["LD"];	//Distance of last thunderstorm
		$lightning_time = $apiData["LT"];	//Unix Time last lightning
		
		//$lightning_day = $apiData["LTot"];	//Fulmini totali nella giornata
		//$lightning_5min = $apiData["L5"];	//Fulmini negli ultimi 5 minuti
		//$lightning_60min = $apiData["L60"];	//Fulmini negli ultimi 60 minuti
	}
	else{
		die("API file not found.");
	}

	//date_default_timezone_set("UTC");
	//echo "UTC:".time();
	//echo "<br>";		
	$dateTimeZone = new DateTimeZone($stationTZ);
	date_default_timezone_set($dateTimeZone);
	$dateTime = new DateTime("now", $dateTimeZone);
	$my = $dateTimeZone->getOffset($dateTime);
	$offset = $my/3600; 
	$tnow=time();
	
	//Test	
	//$lightning_dist=rand(20,22);
	//$lightning_time=time()-rand(60,120);

	# If lightning time is greater then 20 minutes then lightning_dist=0
	#$time_last=round(($tnow-$lightning_time)/60);
	#if($time_last > 20){
	#	$lightning_dist = 0;
	#}	
	
	
	//Load data of last lightning to calculate approach speed 
	if(file_exists("./cache/data.txt")){
		$StoreData = json_decode(file_get_contents("./cache/data.txt"), true);
		// Nota: non posso usare il file cache, si aggiorna troppo velocemente e non si evidenzia lo spostamento
		// del fronte. Meglio usare il Database dove i dati vengono registrati ogni 5 minuti
		//$lastdistance = $StoreData["Lighting_LastDist"];
		//$lastTime = $StoreData["Lighting_LastTime"];
		
		// Thunderstorm direction
		// select distance 5 minutes ago
		// see distance of now
		if(mysqli_num_rows(mysqli_query($con,"SHOW COLUMNS FROM `$dbName`.`alldataExtra` LIKE `LD`;")) > 0){
		//Check for the first time if the columns are present
			$result = mysqli_query($con, "
				SELECT DateTime, LD 
				FROM alldataExtra
				ORDER BY DateTime DESC
				LIMIT 1
				"
			);
		} else { // columns do not exist, create it
			mysqli_query($con,
			"
				 ALTER  TABLE  `$dbName`.`alldataExtra` 
				 ADD COLUMN `L` int( 4) NULL,
				 ADD COLUMN `LD` int( 2) NULL,
				 ADD COLUMN `LT` int( 10) NULL
			"
			);
		}
		
		
		$result = mysqli_query($con, "
				SELECT DateTime, LD 
				FROM alldataExtra
				ORDER BY DateTime DESC
				LIMIT 1
				"
		);
		while ($row = mysqli_fetch_array($result)) {
			$time_last=round(($tnow-$lightning_time)/60);
			if($time_last < 40){
				$lastdistance = $row['LD'];
			} else {
				# If lightning time is greater then 40 minutes then lastdistance=0
				$lastdistance = 0;
			}	
		}
		
		
		$result = mysqli_query($con, "
			SELECT DateTime, LT 
			FROM alldataExtra
			ORDER BY DateTime DESC
			LIMIT 1
			"
		);
		while ($row = mysqli_fetch_array($result)) {
		$lasttime = $row['LT'];
		}	
		
		# If lightning time is greater then 20 minutes then lightning_dist=0
		$time_last=round(($tnow-$lightning_time)/60);
		if($time_last > 40){
			$lightning_dist = 0;
		}	
	
	
	}
	else{
		$lastdistance = $lightning_dist;
		$lasttime = $lightning_time;
	}
	
	//Sum of strikes last hour	
	$result = mysqli_query($con, "
		SELECT  DateTime, MAX(L) AS L_max60min
		FROM  alldataExtra
		WHERE DateTime >= now() - interval 60 minute
		ORDER BY DateTime
		"
	);
	while ($row = mysqli_fetch_array($result)) {
		$time_last=round(($tnow-$lightning_time)/60);
		if($time_last<60){
			$lightning_60min = $row['L_max60min'];
		} else {
			# If lightning time is greater then 60 minutes then do not consider lightnings
			$lightning_60min = 0;
		}	
	}

	//Sum of strikes last 5 minutes 	
	$result = mysqli_query($con, "
		SELECT  DateTime, MAX(L) AS L_max5min
		FROM  alldataExtra
		WHERE DateTime >= now() - interval 5 minute
		ORDER BY DateTime
		"
	);
	while ($row = mysqli_fetch_array($result)) {
		$time_last=round(($tnow-$lightning_time)/60);
		if($time_last<6){
			$lightning_5min = $row['L_max5min'];
		} else {
			# If lightning time is greater then 5 minutes then do not consider lightnings
			$lightning_5min = 0;
		}	
	}
	
	//Sum of strikes last 24 hours	
	$result = mysqli_query($con, "
		SELECT  DateTime, MAX(L) AS L_max24h
		FROM  alldataExtra
		WHERE DateTime >= now() - interval 1 day
		ORDER BY DateTime
		"
	);
	while ($row = mysqli_fetch_array($result)) {
		$time_last=round(($tnow-$lightning_time)/60);
		if($time_last<1440){
			$lightning_day = $row['L_max24h'];
		} else {
			# If lightning time is greater then 24 hours then do not consider lightnings
			$lightning_day = 0;
		}	
	}	
	
	
	// Last strike
	//$tnow=time();
	$lasttimeNow=round(($tnow-$lightning_time)/60);

	switch ($lasttimeNow) {
		case ($lasttimeNow > 1440):
			$timelast = "more than 1 day ago";
			break;
		case ($lasttimeNow > 720):
			$timelast = "more than 12 hours ago";
			break;
		case ($lasttimeNow > 360):
			$timelast = "more than 6 hours ago";
			break;
		case ($lasttimeNow >180):
			$timelast = "more than 3 hours ago";
			break;
		case ($lasttimeNow >60):
			$timelast = "more than 1 hour ago";
			break;
		case ($lasttimeNow <60):
			$timelast = $lasttimeNow . " min ago";
			break;
		default:
			$timelast = "---";	
	}

	if ($lightning_dist !=0){
		$lastdistance_txt = 'Storm activity at:'. $lightning_dist .' km';
	}
	else{
		$lastdistance_txt = 'No active storm';
	}
		
	$diffdist=$lightning_dist-$lastdistance;
	$difftime=$lightning_time-$lasttime;
	$speedkmh=round(abs($diffdist/($difftime/3600)));
	$timetoarrive=round(($lightning_dist/$speedkmh)*60,0);

	if($lightning_dist != NULL && $lightning_dist <= 5) { 
		$Tunder_Txt ="WARNING ! Storm is local !";
		$Tunder_color = "red";
	} 
	else if($lastdistance != NULL && $lightning_dist != NULL && $lastdistance > $lightning_dist){ 
		$Tunder_Txt = "Storm is approaching at ".$speedkmh ." Km/h <br>ETA in ".$timetoarrive ." minutes";
		//$Tunder_Txt = "Storm is approaching at ".$speedkmh ." Km/h <br>ETA in ".$timetoarrive ." minutes <br>last:" .$lastdistance. "- Actual:" .$lightning_dist ." - <br> tnow:" .$tnow. "-";
		
		$Tunder_color = "red";
	} 
	else if($lastdistance != NULL && $lightning_dist != NULL && $lastdistance < $lightning_dist){
		$Tunder_Txt = "Storm is going away ".$speedkmh ." Km/h";
		//$Tunder_Txt = "Storm is going away ".$speedkmh ." Km/h <br>last:" .$lastdistance. "- Actual:" .$lightning_dist ." - <br> tnow:" .$tnow. "-";
		$Tunder_color =" green";
	} 
	else if($lastdistance != NULL && $lightning_dist != NULL && $lastdistance = $lightning_dist){
		$Tunder_Txt ="Storm is not moving";
		//$Tunder_Txt ="Storm is not moving <br>last:" .$lastdistance. "- Actual:" .$lightning_dist ." - <br> tnow:" .$tnow. "-";
		$Tunder_color = "yellow";
	} 
	else {
		$Tunder_Txt = "last:" .$lastdistance. "- Actual:" .$lightning_dist ."-";
		$Tunder_color = "green";
	}

	//Test
	//$Tunder_Txt =$lastTime; 
	//$Tunder_color = "red";

	if($lightning_dist != 0 && $lightning_dist > 70){
		$fulmini['outer-1']="lime";
		$fulmini['inner-1']="lime";
		$fulmini['inner-2']="lime";
		$fulmini['inner-3']="lime";
		$fulmini['inner-4']="lime";
	}

	if($lightning_dist != 0 && $lightning_dist <= 70 && $lightning_dist > 30 ){
		$fulmini['outer-1']="red";
	}
	else {
		$fulmini['outer-1']="lime";
	}
	
	if($lightning_dist != 0 && $lightning_dist <= 30 && $lightning_dist > 20 ){
		$fulmini['inner-1']="red";
	}
	else {
		$fulmini['inner-1']="lime";
	}
	
	if($lightning_dist != 0 && $lightning_dist <= 20 && $lightning_dist > 10 ){
		$fulmini['inner-2']="red";
	}
	else {
		$fulmini['inner-2']="lime";
	}

	if($lightning_dist != 0 && $lightning_dist <= 10 && $lightning_dist > 5 ){
		$fulmini['inner-3']="red";
	}
	else {
		$fulmini['inner-3']="lime";
	}

	if($lightning_dist != 0 && $lightning_dist <=  5 ){
		$fulmini['inner-4']="red";
	}
	else {
		$fulmini['inner-4']="lime";
	}
	
	if ($lightning_dist==0){
		$fulmini['Lighting_LastDist']= '';
	}
	else {
		$fulmini['Lighting_LastDist']= $lightning_dist;
	}

	$LastFulmine['Lighting_LastDist']=$lightning_dist;
	$LastFulmine['Lighting_LastTime']=$lightning_time;
	
	$fulmini['Lighting_Dist']= $lightning_dist;
	$fulmini['LastStrike'] = $timelast;
	$fulmini['Lightning_60min'] = $lightning_60min;
	$fulmini['Lastdistance_txt'] = $lastdistance_txt;
	$fulmini['Lighting_Today'] = $lightning_day;
	$fulmini['Lightning_5min'] = $lightning_5min;
	$fulmini['Tunder_txt']= $Tunder_Txt;
	$fulmini['Tunder_color']= $Tunder_color;
	
	if(file_exists("./cache/dati.txt")){
		unlink("./cache/dati.txt");
	}
	file_put_contents("./cache/dati.txt", json_encode($fulmini));
	
		if(file_exists("./cache/data.txt")){
		unlink("./cache/data.txt");
	}
	file_put_contents("./cache/data.txt", json_encode($LastFulmine));
	
	$fulmini = json_encode($fulmini);
	echo $fulmini;
?>