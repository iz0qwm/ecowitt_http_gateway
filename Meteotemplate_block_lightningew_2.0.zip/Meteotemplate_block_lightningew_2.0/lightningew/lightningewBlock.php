<?php

	# 		Ecowitt GW1000 Lightning
	# 		Namespace:		lightningew
	#		Meteotemplate Block

	# 		v1.0 - Apr 9, 2017 
	# 			- initial release
	#       v2.0 - March 17, 2020
	#           - use of cache file thanks to Giuseppe Chiodaroli iw2jzq

	
		
	// load theme
	$designTheme = json_decode(file_get_contents("../../css/theme.txt"),true);
	$theme = $designTheme['theme'];
	
	include("../../../config.php");
	include("../../../css/design.php");
	include("../../../scripts/functions.php");
	
	$languageRaw = file_get_contents($baseURL."lang/gb.php");
	$language['gb'] = json_decode($languageRaw,true);
	$languageRaw = file_get_contents($baseURL."lang/".$lang.".php");
	$language[$lang] = json_decode($languageRaw,true);

?>
	<style>
		
		.distKm{
			font-size: 1.0em;
			opacity: 0.8;
			cursor: pointer;
			padding: 3px;
		}
		
		.dayPieSwitcher, #dayPieCalendarIcon{
			font-size: 1.5em;
			opacity: 0.8;
			cursor: pointer;
			padding: 3px;
		}
		.dayPieSwitcher:hover, #dayPieCalendarIcon:hover{
			opacity: 1;
		}
		#dayPieCalendarIcon{
			font-size:2.5em!important;
		}
		#dayPieCalendar .ui-datepicker-month{
			font-size:12px!important;
		}
	</style>
	
	
	<style>
		.outer-1 {
						background-color:lime;
						width:200px; /* You can define it by % also */
						height:200px; /* You can define it by % also*/
						position:relative;
						border:1px solid black;
						border-radius: 50%;
		}
		.inner-1 {
						background-color:lime;
						top: 10%; left:10%; /* of the container */
						width:80%; /* of the outer-1 */
						height:80%; /* of the outer-1 */
						position: absolute;
						border:1px solid black;
						border-radius: 50%;
		}
		.inner-2 {
						background-color:lime;
						top: 20%; left:20%; /* of the container */
						width:60%; /* of the inner-1 */
						height:60%; /* of the inner-1 */
						position: absolute;
						border:1px solid black;
						border-radius: 50%;
		}
		.inner-3 {
						background-color:lime;
						top: 30%; left:30%; /* of the container */
						width:40%; /* of the inner-1 */
						height:40%; /* of the inner-1 */
						position: absolute;
						border:1px solid black;
						border-radius: 50%;
		}	
		.inner-4 {
						background-color:lime;
						top: 40%; left:40%; /* of the container */
						width:20%; /* of the inner-1 */
						height:20%; /* of the inner-1 */
						position: absolute;
						border:1px solid black;
						border-radius: 50%;
		}	

		#cellimage {
			background-image: url("http://www.kwos.org/poggiocorese_ecowitt/homepage/blocks/lightningew/lightning_maps_circle_NO.png");
		}		
	</style>

	<!-- <span class="mticon-temp" style="font-size:2.7em"></span> -->
	<h2><span class="fa fa-bolt" style="font-size:1.0em"></span> <?php echo lang('current lightning data ','c')?><font size="3" color="yellow" id="time"></font></h2>
		<table style="width:98%;margin:0 auto">
		<tr>
			<td colspan="2" style="width:100%; line-height: 1.8em;">
				<!---<b><font size="3" color="yellow" id="time"></font></b> -->
			</td>
		</tr>
	</table>
	<table style="width:98%;margin:0 auto">
		<tr>
			<td id="cellimage" style="width:50%">
				<!-- <div class="outer-1"> -->
						<div class="outer-1" id="cerchio_outer-1" style="opacity: 0.5;" >
							<b><span style="font-size:0.9em;color:black" id="distKm">40Km</span></b>					
						<div class="inner-1" id="cerchio_inner-1" >
							<b><span style="font-size:0.9em;color:black" id="distKm">30Km</span></b>
						</div>
						<div class="inner-2" id="cerchio_inner-2" >
							<b><span style="font-size:0.9em;color:black" id="distKm">20Km</span></b>
						</div>
						<div class="inner-3" id="cerchio_inner-3" >
							<b><span style="font-size:0.9em;color:black" id="distKm">10Km</span></b>
						</div>
						<div class="inner-4" id="cerchio_inner-4" style="background-color:lime">
							<b><span style="font-size:0.9em;color:black" id="distKm">5Km</span></b>
						</div>
			</td>
			<td style="width:50%">
				<table style="width:100%; border-collapse: collapse; text-align: left; margin:0 auto">
					<tr>
						<td style="width:100%; border-bottom: 1px solid #ccc; line-height: 1em; text-align: left; padding: 10px;">
							<span id="Lightning_dist_txt"></span>
						<br>
						</td>
					</tr>
					<tr>
						<td style="width:100%;border-bottom: 1px solid #ccc; line-height: 1em; text-align: left;padding: 10px; ">
						<?php echo lang('Strikes today','c')?>: <span id="Lightning_Today"></span>
						</td>
					</tr>
					<tr>
						<td style="width:100%;border-bottom: 1px solid #ccc; line-height: 1em; text-align: left;padding: 10px; ">
						<?php echo lang('Strikes last 5 min','c')?>: <span id="Lightning_5min"></span>
						</td>
					</tr>
					<tr>
						<td style="width:100%;border-bottom: 1px solid #ccc; line-height: 1em; text-align: left; padding: 10px;">
						<?php echo lang('Strikes 60min','c')?>: <span id="Lightning_60min"></span>
						</td>
					</tr>
					<tr>
						<td style="width:100%; border-bottom: 1px solid #ccc; line-height: 1em; text-align: left; padding: 10px;">
						<?php echo lang('Last strike','c')?>: <span id="LastStrike"></span> 
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="2" style="width:100%; line-height: 1.8em;">
				<b><font size="3" color="blue" id="Tunder_Txt"></font></b>
			</td>
		</tr>
	
	</table>
<script>

var myVar = setInterval(updater, 10000);
	function updater(){
		var d = new Date();
		var t = d.toLocaleTimeString();
		
		$.ajax({
			url : "homepage/blocks/lightningew/lightningewupdater.php?interval=1",
			dataType : 'json',
			success : function (json) {
				$("#LastStrike").html(json['LastStrike']);
				$("#Lightning_60min").html(json['Lightning_60min']);
				$("#Lightning_dist_txt").html(json['Lastdistance_txt']);
				$("#Lightning_Today").html(json['Lighting_Today']);
				$("#Lightning_5min").html(json['Lightning_5min']);
				$("#Tunder_Txt").html(json['Tunder_txt']);
				$("#Tunder_Txt").css("color",json['Tunder_color']);
				$("#cerchio_outer-1").css("background-color",json['outer-1']);
				$("#cerchio_inner-1").css("background-color",json['inner-1']);
				$("#cerchio_inner-2").css("background-color",json['inner-2']);
				$("#cerchio_inner-3").css("background-color",json['inner-3']);
				$("#cerchio_inner-4").css("background-color",json['inner-4']);
			},
			error: function(xhr) {
				console.log(xhr.status); // es. 404 Not Found
				$("#Tunder_Txt").html("Errore");
			}
		});
		//$("#Test").html(prova);
		$("#time").html(t);

	}

	
</script>	