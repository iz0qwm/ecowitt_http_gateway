The Meteotemplate doesn't have the L, LD, LT, fields in the database and in the api.php so 
there are more files to update.
You find them in the Meteotemplate directory of my github:

"api.php" and all the "update/" directory. 
The files inside the update directory must be in the directory of Meteotemplate 
with the same name "update"

https://github.com/iz0qwm/ecowitt_http_gateway/tree/master/Meteotemplate

NOT the "plugins/ecowitt", you don't need it if you don't use the Ecowitt plugin.

I don't know if Meteobridge sends the lightning data to meteotemplate so please check this 
before installing this plugin if you have such hardware.

